import csv
h=['0','0','0','0','0','0']
with open("lab1.csv") as csv_file:
    readcsv=csv.reader(csv_file,delimiter=",")
    data=[]
    print("The given training example are:")
    for row in readcsv:
        print(row)
        if row[-1].upper()=="YES":
            data.append(row)
   
print("Positive Training examples are:")
for row in data:
    print(row)
print("Steps")
print("Initial Hypothesis:")
i=0
j=0
total=len(data)
li=[]
d=len(data[i])-1
for j in range(d):
    li.append(data[i][j])
    hypo=li
for i in range(1,total):
    for j in range(d):
        if(hypo[j]!=data[i][j]):
            hypo[j]='?'
    print(hypo)
print("Hypothesis")
print(hypo)