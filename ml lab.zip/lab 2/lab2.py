import numpy as np
import pandas as pd
data=pd.read_csv('lab2.csv')#,delimiter=',')
attr=np.array(data.values[:,0:-1])
tar=np.array(data.values[:,-1])
print(tar)
def cand(attr,tar):
    spec=attr[0].copy()
    gen=[["?" for i in range(len(spec))] for i in range(len(spec))]
    print("initialize spec,gen")
    print(spec)
    print(gen)
    for i,h in enumerate(attr):
        if tar[i]=="yes":
            for x in range(len(spec)):
                if(h[x]!=spec[x]):
                    spec[x]='?'
                    gen[x][x]='?'
                elif(gen[x-1]!=spec[x]):
                    gen[x][x]=h[x]
                elif(x==0):
                    spec[x]=h[x]
        else:
            for x in range(len(spec)):
                if(h[x]!=spec[x-1]):
                    gen[x][x]=spec[x]
                else:
                    gen[x][x]='?'
        print('steps of ce',i+1)
        print(spec)
        print(gen)
    ind=[i for i,val in enumerate(gen) if val==['?','?','?','?','?']]
    for i in ind:
        gen.remove(['?','?','?','?','?'])
    return spec,gen
sf,gf=cand(attr,tar)
print("final sh:",sf)
print("final gh:",gf)
